document.getElementById("formLogin").addEventListener("submit", event => {
  event.preventDefault();

  const email = document.getElementById("email").value;
  const senha = document.getElementById("senha").value;

  if (!fazerLogin(email, senha)) {
    alert("E-mail ou senha invalidos.");
    return;
  }

  irPosLogin();
});
