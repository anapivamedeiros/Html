if (exigirAdmin()) {
  listarUsuarios();
}

document.getElementById("formUsuario").addEventListener("submit", event => {
  event.preventDefault();

  const id = document.getElementById("usuarioId").value;
  const dados = {
    nome: document.getElementById("nome").value,
    email: document.getElementById("email").value,
    senha: document.getElementById("senha").value,
    role: document.getElementById("role").value
  };

  try {
    if (id) {
      atualizarUsuario(id, dados);
    } else {
      if (!dados.senha) {
        alert("Informe uma senha para o novo usuario.");
        return;
      }

      registrarUsuario(dados);
    }

    limparFormularioUsuario();
    listarUsuarios();
  } catch (erro) {
    alert(erro.message);
  }
});

function listarUsuarios() {
  const lista = document.getElementById("listaUsuarios");

  lista.innerHTML = obterUsuarios().map(usuario => `
    <div class="bg-white border border-pink-100 rounded-xl shadow p-4 flex items-center justify-between gap-4">
      <div>
        <h3 class="font-bold text-lg">${usuario.nome}</h3>
        <p class="text-sm text-gray-500">${usuario.email}</p>
        <span class="inline-block mt-2 text-xs font-bold px-2 py-1 rounded bg-pink-50 text-pink-600">${usuario.role}</span>
      </div>
      <div class="flex gap-2">
        <button onclick="editarUsuario(${usuario.id})" class="bg-yellow-400 text-white px-3 py-2 rounded-lg">Editar</button>
        <button onclick="excluirUsuario(${usuario.id})" class="bg-red-500 text-white px-3 py-2 rounded-lg">Excluir</button>
      </div>
    </div>
  `).join("");
}

function editarUsuario(id) {
  const usuario = obterUsuarios().find(item => item.id === Number(id));

  document.getElementById("usuarioId").value = usuario.id;
  document.getElementById("nome").value = usuario.nome;
  document.getElementById("email").value = usuario.email;
  document.getElementById("senha").value = "";
  document.getElementById("role").value = usuario.role;
}

function excluirUsuario(id) {
  if (!confirm("Excluir usuario?")) {
    return;
  }

  try {
    removerUsuario(id);
    listarUsuarios();
  } catch (erro) {
    alert(erro.message);
  }
}

function limparFormularioUsuario() {
  document.getElementById("usuarioId").value = "";
  document.getElementById("nome").value = "";
  document.getElementById("email").value = "";
  document.getElementById("senha").value = "";
  document.getElementById("role").value = "USER";
}
