const API = "http://localhost:8080";

const params = new URLSearchParams(window.location.search);
const categoriaId = Number(params.get("id"));

// =====================
// TÍTULO DA CATEGORIA
// =====================
fetch(API + "/categoria")
  .then(res => res.json())
  .then(categorias => {
    const categoria = categorias.find(c => c.id === categoriaId);

    if (categoria) {
      document.getElementById("titulo").innerText = categoria.nome;
    }
  });

// =====================
// PRODUTOS
// =====================
fetch(API + "/produto")
  .then(res => res.json())
  .then(produtos => {

    const container = document.getElementById("listaProdutos");
    container.innerHTML = "";

    const filtrados = produtos.filter(p =>
      Number(p.categoria?.id) === categoriaId
    );

    if (filtrados.length === 0) {
      container.innerHTML = `
        <p class="text-center col-span-full text-gray-500">
          Nenhum produto encontrado.
        </p>
      `;
      return;
    }

    filtrados.forEach(p => {
      container.innerHTML += `
      <a href="descricao.html?id=${p.id}">
        <div class="bg-white rounded-2xl shadow-md hover:shadow-2xl transition overflow-hidden flex flex-col">

          <!-- IMAGEM -->
          <div class="h-48 bg-gray-100 overflow-hidden">
            <img 
              src="${p.imagem || 'https://via.placeholder.com/400x300'}"
              class="w-full h-full object-cover hover:scale-105 transition duration-300"
            >
          </div>

          <!-- CONTEÚDO -->
          <div class="p-5 flex flex-col flex-1">

            <!-- NOME -->
            <h2 class="text-lg font-bold text-gray-800 mb-1">
              ${p.nome}
            </h2>

            <!-- DESCRIÇÃO -->
            <p class="text-sm text-gray-500 mb-3 line-clamp-2">
              ${p.descricao || "Sem descrição"}
            </p>

            <!-- PREÇO -->
            <div class="mt-auto">

              <p class="text-2xl font-extrabold text-pink-500">
                R$ ${Number(p.preco).toFixed(2)}
              </p>

              <!-- ESTOQUE -->
              <p class="text-xs text-gray-400 mb-3">
                Estoque: ${p.qtdEstoque ?? 0}
              </p>

              <!-- BOTÃO -->
              <button class="w-full bg-pink-400 hover:bg-pink-500 text-white font-semibold py-2 rounded-lg transition">
                Ver produto
              </button>

            </div>

          </div>

        </div>
      `;
    });

  })
  .catch(err => console.error("Erro:", err));






