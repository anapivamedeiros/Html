const API = "http://localhost:8080";
const IMAGEM_PADRAO = "https://placehold.co/400x300";

function montarUrlImagem(imagem) {
  if (!imagem || imagem === "null" || imagem === "undefined") {
    return IMAGEM_PADRAO;
  }

  const caminho = String(imagem).trim().replace(/^["']|["']$/g, "");

  if (
    caminho.startsWith("http://") ||
    caminho.startsWith("https://") ||
    caminho.startsWith("data:") ||
    caminho.startsWith("blob:")
  ) {
    return caminho;
  }

  if (caminho.startsWith("/uploads/")) {
    return `${API}${caminho}`;
  }

  if (caminho.startsWith("uploads/")) {
    return `${API}/${caminho}`;
  }

  const nomeArquivo = caminho.split("\\").pop().split("/").pop();
  return `${API}/uploads/${nomeArquivo}`;
}

function resumirDescricao(descricao, limite = 70) {
  const texto = String(descricao || "").trim();

  if (texto.length <= limite) {
    return escaparHtml(texto);
  }

  return `${escaparHtml(texto.slice(0, limite).trim())}... <span class="font-bold">mais</span>`;
}

function escaparHtml(texto) {
  return String(texto || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

const params = new URLSearchParams(window.location.search);
const categoriaId = Number(params.get("id"));

// =====================
// TÍTULO DA CATEGORIA
// =====================
fetch(`${API}/categoria`)
  .then(res => res.json())
  .then(categorias => {

    const categoria = categorias.find(c => c.id === categoriaId);

    if (categoria) {
      document.getElementById("titulo").innerText = categoria.nome;
    } else {
      document.getElementById("titulo").innerText = "Categoria não encontrada";
    }
  })
  .catch(err => console.error("Erro categoria:", err));


// =====================
// PRODUTOS
// =====================
fetch(`${API}/produto`)
  .then(res => res.json())
  .then(produtos => {

    const container = document.getElementById("listaProdutos");
    container.innerHTML = "";

    const filtrados = produtos.filter(p =>
      Number(p.categoria?.id) === categoriaId
    );

    if (filtrados.length === 0) {
      container.innerHTML = `
        <p class="text-center col-span-full text-gray-500 text-lg">
          Nenhum produto encontrado.
        </p>
      `;
      return;
    }

    filtrados.forEach(p => {

  const imagem = montarUrlImagem(p.imagem);
  const descricaoResumida = resumirDescricao(p.descricao);

  container.innerHTML += `
    <a href="descricao.html?id=${p.id}">
      <div class="bg-white rounded-2xl shadow-md overflow-hidden">

        <div class="h-56 bg-gray-100">
          <img 
            src="${imagem}"
            class="w-full h-full object-cover"
            onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'"
          >
        </div>

        <div class="p-5">
          <h2 class="font-bold text-lg text-gray-800 mb-1">${p.nome}</h2>
          <p class="font-normal text-gray-600">${descricaoResumida}</p>
        

        <p class="text-2xl font-extrabold text-grey-500 mb-2">
                R$ ${Number(p.preco).toFixed(2)}
              </p>

              <p class="text-sm text-gray-400 mb-4">
                Estoque: ${p.qtdEstoque ?? 0}
              </p>

              <button class="w-full bg-yellow-300 hover:bg-yellow-500 text-white font-semibold py-2 rounded-lg">
                Ver produto
              </button>

            </div>
</div>
      </div>
    </a>
  `;
});


  })
  .catch(err => console.error("Erro produtos:", err));
