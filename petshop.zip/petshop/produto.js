const API = "http://localhost:8080";
const IMAGEM_PADRAO = "https://placehold.co/400x300";

function montarUrlImagem(imagem) {
  if (!imagem || imagem === "null" || imagem === "undefined") {
    return IMAGEM_PADRAO;
  }

  const caminho = String(imagem).trim().replace(/^["']|["']$/g, "");

  if (
    caminho.startsWith("http://") ||
    caminho.startsWith("https://") ||
    caminho.startsWith("data:") ||
    caminho.startsWith("blob:")
  ) {
    return caminho;
  }

  if (caminho.startsWith("/uploads/")) {
    return `${API}${caminho}`;
  }

  if (caminho.startsWith("uploads/")) {
    return `${API}/${caminho}`;
  }

  const nomeArquivo = caminho.split("\\").pop().split("/").pop();
  return `${API}/uploads/${nomeArquivo}`;
}

function verificarResposta(res, etapa) {
  if (res.ok) {
    return res;
  }

  return res.text().then(texto => {
    throw new Error(`${etapa}: ${texto || `Erro ${res.status}`}`);
  });
}

function resumirDescricao(descricao, limite = 90) {
  const texto = String(descricao || "").trim();

  if (texto.length <= limite) {
    return texto;
  }

  return `${texto.slice(0, limite).trim()}... mais`;
}

function escaparHtml(texto) {
  return String(texto || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function alternarDescricaoProduto(card) {
  const descricao = card.querySelector("[data-descricao-produto]");

  if (!descricao) {
    return;
  }

  const expandida = descricao.dataset.expandida === "true";
  descricao.textContent = expandida
    ? descricao.dataset.resumida
    : descricao.dataset.completa;
  descricao.dataset.expandida = String(!expandida);
}

function validarFormularioProduto() {
  const nome = document.getElementById("nome").value.trim();
  const descricao = document.getElementById("descricao").value.trim();
  const categoria = document.getElementById("categoria").value;

  if (!nome || !descricao) {
    alert("Preencha nome e descrição.");
    return false;
  }

  if (!categoria) {
    alert("Selecione uma categoria.");
    return false;
  }

  if (nome.length > 80) {
    alert("O nome pode ter no máximo 80 caracteres.");
    return false;
  }

  if (descricao.length > 180) {
    alert("A descrição pode ter no máximo 180 caracteres.");
    return false;
  }

  return true;
}

// ================= CARREGAR CATEGORIAS =================
function carregarCategorias() {
  fetch(API + "/categoria")
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById("categoria");

      select.innerHTML = `<option value="">Selecione uma categoria</option>`;

      data.forEach(c => {
        select.innerHTML += `
          <option value="${c.id}">
            ${c.nome}
          </option>
        `;
      });
    })
    .catch(err => console.error("Erro categorias:", err));
}

// ================= SALVAR (COM IMAGEM) =================
function salvarProduto() {
  let fileInput = document.getElementById("imagem");
  const nome = document.getElementById("nome").value.trim().slice(0, 80);
  const descricao = document.getElementById("descricao").value.trim().slice(0, 180);
  const categoriaId = Number(document.getElementById("categoria").value);
  const editandoId = window.produtoEditandoId;

  if (!validarFormularioProduto()) {
    return;
  }

  if (!editandoId && (!fileInput.files || fileInput.files.length === 0)) {
    alert("Escolha uma imagem para o produto.");
    return;
  }

  const salvarComImagem = imagem => {
    let produto = {
      nome: nome,
      descricao: descricao,
      preco: document.getElementById("preco").value,
      qtdEstoque: document.getElementById("estoque").value,
      imagem: imagem,
      categoria: {
        id: categoriaId
      }
    };

    const url = editandoId ? `${API}/produto/${editandoId}` : `${API}/produto`;
    const metodo = editandoId ? "PUT" : "POST";

    return fetch(url, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(produto)
    }).then(res => verificarResposta(res, "Erro ao salvar produto"));
  };

  const uploadImagem = () => {
    let formData = new FormData();
    formData.append("file", fileInput.files[0]);

    return fetch(API + "/produto/upload", {
      method: "POST",
      body: formData
    })
      .then(res => verificarResposta(res, "Erro no upload da imagem"))
      .then(res => res.text())
      .then(urlImagem => String(urlImagem).trim().replace(/^["']|["']$/g, ""));
  };

  const acaoSalvar = fileInput.files && fileInput.files.length > 0
    ? uploadImagem().then(salvarComImagem)
    : salvarComImagem(window.produtoEditandoImagem || "");

  acaoSalvar
    .then(() => {
      alert("Produto salvo!");
      limparFormulario();
      listarProdutos();
    })
    .catch(err => {
      console.error("Erro ao salvar produto:", err);
      alert(`Erro ao salvar produto: ${err.message}`);
    });
}

// ================= LISTAR PRODUTOS =================
function listarProdutos() {
  fetch(API + "/produto")
    .then(res => res.json())
    .then(produtos => {
      const container = document.getElementById("listaProdutos");
      container.innerHTML = "";

      produtos.forEach(p => {
        let imgSrc = montarUrlImagem(p.imagem);
        const descricaoCompleta = p.descricao || "";
        const descricaoResumida = resumirDescricao(descricaoCompleta);
        const descricaoCompletaHtml = escaparHtml(descricaoCompleta);
        const descricaoResumidaHtml = escaparHtml(descricaoResumida);

        container.innerHTML += `
          <div onclick="alternarDescricaoProduto(this)"
            class="bg-white p-4 rounded shadow mb-3 flex items-center justify-between gap-4 cursor-pointer">

            <img src="${imgSrc}"
              class="w-20 h-20 object-cover rounded"
              onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'">

            <div class="flex-1 min-w-0">
              <h3 class="font-bold text-lg break-words">${p.nome}</h3>
              <p class="text-sm text-gray-600 break-words whitespace-pre-wrap"
                data-descricao-produto
                data-completa="${descricaoCompletaHtml}"
                data-resumida="${descricaoResumidaHtml}"
                data-expandida="false">${descricaoResumidaHtml}</p>
              <p class="text-sm">Preço: R$ ${p.preco}</p>
              <p class="text-sm">Estoque: ${p.qtdEstoque}</p>
              <p class="text-xs text-gray-500">
                ${p.categoria?.nome || "Sem categoria"}
              </p>
            </div>

            <div class="flex flex-col gap-2">
              <button onclick="event.stopPropagation(); editarProduto(${p.id})"
                class="bg-yellow-400 text-white px-3 py-1 rounded text-sm">
                Editar
              </button>

              <button onclick="event.stopPropagation(); deletarProduto(${p.id})"
                class="bg-red-500 text-white px-3 py-1 rounded text-sm">
                Excluir
              </button>
            </div>

          </div>
        `;
      });
    })
    .catch(err => console.error(err));
}

// ================= DELETAR =================
function deletarProduto(id) {
  if (!confirm("Excluir produto?")) return;

  fetch(API + "/produto/" + id, {
    method: "DELETE"
  })
    .then(() => listarProdutos())
    .catch(err => console.error(err));
}

// ================= EDITAR =================
function editarProduto(id) {
  fetch(API + "/produto/" + id)
    .then(res => res.json())
    .then(p => {
      document.getElementById("nome").value = p.nome;
      document.getElementById("descricao").value = p.descricao;
      document.getElementById("preco").value = p.preco;
      document.getElementById("estoque").value = p.qtdEstoque;
      document.getElementById("categoria").value = p.categoria?.id;

      window.produtoEditandoId = id;
      window.produtoEditandoImagem = p.imagem || "";
    });
}

// ================= LIMPAR =================
function limparFormulario() {
  document.getElementById("nome").value = "";
  document.getElementById("descricao").value = "";
  document.getElementById("preco").value = "";
  document.getElementById("estoque").value = "";
  document.getElementById("categoria").value = "";
  document.getElementById("imagem").value = "";
  window.produtoEditandoId = null;
  window.produtoEditandoImagem = "";
}

// ================= INIT =================
window.onload = () => {
  carregarCategorias();
  listarProdutos();
};
