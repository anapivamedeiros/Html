const API = "http://localhost:8080";
const IMAGEM_PADRAO = "https://placehold.co/400x300";

if (typeof exigirAdmin === "function") {
  exigirAdmin();
}

function montarUrlImagem(imagem) {
  if (!imagem || imagem === "null" || imagem === "undefined") {
    return IMAGEM_PADRAO;
  }

  const caminho = String(imagem).trim().replace(/^["']|["']$/g, "");

  if (
    caminho.startsWith("http://") ||
    caminho.startsWith("https://") ||
    caminho.startsWith("data:") ||
    caminho.startsWith("blob:")
  ) {
    return caminho;
  }

  if (caminho.startsWith("/uploads/")) {
    return `${API}${caminho}`;
  }

  if (caminho.startsWith("uploads/")) {
    return `${API}/${caminho}`;
  }

  const nomeArquivo = caminho.split("\\").pop().split("/").pop();
  return `${API}/uploads/${nomeArquivo}`;
}

function verificarResposta(res, etapa) {
  if (res.ok) {
    return res;
  }

  return res.text().then(texto => {
    throw new Error(`${etapa}: ${texto || `Erro ${res.status}`}`);
  });
}

function resumirDescricao(descricao, limite = 90) {
  const texto = String(descricao || "").trim();

  if (texto.length <= limite) {
    return texto;
  }

  return `${texto.slice(0, limite).trim()}... mais`;
}

function escaparHtml(texto) {
  return String(texto ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function alternarDescricaoProduto(card) {
  const descricao = card.querySelector("[data-descricao-produto]");

  if (!descricao) {
    return;
  }

  const expandida = descricao.dataset.expandida === "true";
  descricao.textContent = expandida
    ? descricao.dataset.resumida
    : descricao.dataset.completa;
  descricao.dataset.expandida = String(!expandida);
}

function validarFormularioProduto() {
  const nome = document.getElementById("nome").value.trim();
  const descricao = document.getElementById("descricao").value.trim();
  const categoria = document.getElementById("categoria").value;

  if (!nome || !descricao) {
    alert("Preencha nome e descrição.");
    return false;
  }

  if (!categoria) {
    alert("Selecione uma categoria.");
    return false;
  }

  if (nome.length > 80) {
    alert("O nome pode ter no máximo 80 caracteres.");
    return false;
  }

  if (descricao.length > 1000) {
    alert("A descrição pode ter no máximo 1000 caracteres.");
    return false;
  }

  return true;
}

// ================= CARREGAR CATEGORIAS =================
function carregarCategorias() {
  fetch(API + "/categoria")
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById("categoria");

      select.innerHTML = `<option value="">Selecione uma categoria</option>`;

      data.forEach(c => {
        select.innerHTML += `
          <option value="${c.id}">
            ${c.nome}
          </option>
        `;
      });
    })
    .catch(err => console.error("Erro categorias:", err));
}

// ================= SALVAR (COM IMAGEM) =================
function salvarProduto() {
  const fileInput = document.getElementById("imagem");
  const arquivosImagem = Array.from(fileInput.files || []).slice(0, 3);
  const nome = document.getElementById("nome").value.trim().slice(0, 80);
  const descricao = document.getElementById("descricao").value.trim().slice(0, 1000);
  const categoriaId = Number(document.getElementById("categoria").value);
  const editandoId = window.produtoEditandoId;

  if (!validarFormularioProduto()) {
    return;
  }

  if (fileInput.files && fileInput.files.length > 3) {
    alert("Escolha no máximo 3 imagens para o produto.");
    return;
  }

  if (!editandoId && arquivosImagem.length === 0) {
    alert("Escolha pelo menos uma imagem para o produto.");
    return;
  }

  const salvarComImagens = imagens => {
    let produto = {
      nome: nome,
      descricao: descricao,
      preco: document.getElementById("preco").value,
      qtdEstoque: document.getElementById("estoque").value,
      imagem: imagens[0] || "",
      imagem2: imagens[1] || "",
      imagem3: imagens[2] || "",
      categoria: {
        id: categoriaId
      }
    };

    const url = editandoId ? `${API}/produto/${editandoId}` : `${API}/produto`;
    const metodo = editandoId ? "PUT" : "POST";

    return fetch(url, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(produto)
    }).then(res => verificarResposta(res, "Erro ao salvar produto"));
  };

  const uploadImagem = arquivo => {
    let formData = new FormData();
    formData.append("file", arquivo);

    return fetch(API + "/produto/upload", {
      method: "POST",
      body: formData
    })
      .then(res => verificarResposta(res, "Erro no upload da imagem"))
      .then(res => res.text())
      .then(urlImagem => String(urlImagem).trim().replace(/^["']|["']$/g, ""));
  };

  const imagensAtuais = [
    window.produtoEditandoImagem || "",
    window.produtoEditandoImagem2 || "",
    window.produtoEditandoImagem3 || ""
  ];

  const acaoSalvar = arquivosImagem.length > 0
    ? Promise.all(arquivosImagem.map(uploadImagem)).then(salvarComImagens)
    : salvarComImagens(imagensAtuais);

  acaoSalvar
    .then(() => {
      alert("Produto salvo!");
      limparFormulario();
      listarProdutos();
    })
    .catch(err => {
      console.error("Erro ao salvar produto:", err);
      alert(`Erro ao salvar produto: ${err.message}`);
    });
}

// ================= LISTAR PRODUTOS =================
function listarProdutos() {
  fetch(API + "/produto")
    .then(res => res.json())
    .then(produtos => {
      const container = document.getElementById("listaProdutos");
      container.innerHTML = "";

      const produtosPorCategoria = produtos.reduce((grupos, produto) => {
        const categoriaNome = produto.categoria?.nome || "Sem categoria";

        if (!grupos[categoriaNome]) {
          grupos[categoriaNome] = [];
        }

        grupos[categoriaNome].push(produto);
        return grupos;
      }, {});

      Object.keys(produtosPorCategoria)
        .sort((a, b) => a.localeCompare(b, "pt-BR"))
        .forEach(categoriaNome => {
          const produtosDaCategoria = produtosPorCategoria[categoriaNome];
          const quantidade = produtosDaCategoria.length;
          let cardsProdutos = "";

          produtosDaCategoria.forEach(p => {
            const produtoId = p.idProduto ?? p.id;
            let imgSrc = montarUrlImagem(p.imagem);
            const descricaoCompleta = p.descricao || "";
            const descricaoResumida = resumirDescricao(descricaoCompleta);
            const descricaoCompletaHtml = escaparHtml(descricaoCompleta);
            const descricaoResumidaHtml = escaparHtml(descricaoResumida);

            cardsProdutos += `
              <div onclick="alternarDescricaoProduto(this)"
                class="bg-white p-4 rounded shadow flex items-center justify-between gap-4 cursor-pointer min-h-36">

                <img src="${imgSrc}"
                  class="w-24 h-24 object-contain rounded bg-gray-100 p-2 flex-shrink-0"
                  onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'">

                <div class="flex-1 min-w-0 h-28 overflow-hidden">
                  <h4 class="font-bold text-lg break-words h-7 overflow-hidden">${escaparHtml(p.nome)}</h4>
                  <p class="text-sm text-gray-600 break-words h-10 overflow-hidden"
                    data-descricao-produto
                    data-completa="${descricaoCompletaHtml}"
                    data-resumida="${descricaoResumidaHtml}"
                    data-expandida="false">${descricaoResumidaHtml}</p>
                  <p class="text-sm">Preço: R$ ${escaparHtml(p.preco)}</p>
                  <p class="text-sm">Estoque: ${escaparHtml(p.qtdEstoque)}</p>
                  <p class="text-xs text-gray-500">
                    ${escaparHtml(p.categoria?.nome || "Sem categoria")}
                  </p>
                </div>

                <div class="flex flex-col gap-2 flex-shrink-0">
                  <button onclick="event.stopPropagation(); window.location.href='descricao.html?id=${produtoId}'"
                    class="bg-pink-400 text-white px-3 py-1 rounded text-sm">
                    Ver
                  </button>

                  <button onclick="event.stopPropagation(); editarProduto(${p.id})"
                    class="bg-yellow-400 text-white px-3 py-1 rounded text-sm">
                    Editar
                  </button>

                  <button onclick="event.stopPropagation(); deletarProduto(${p.id})"
                    class="bg-red-500 text-white px-3 py-1 rounded text-sm">
                    Excluir
                  </button>
                </div>

              </div>
            `;
          });

          container.innerHTML += `
            <section class="min-w-0">
              <div class="flex items-center justify-between gap-4 mb-3 border-b border-pink-100 pb-2">
                <h3 class="text-2xl font-extrabold text-pink-600 break-words">
                  ${escaparHtml(categoriaNome)}
                </h3>
                <span class="bg-pink-50 text-pink-600 font-semibold text-sm px-3 py-1 rounded-full whitespace-nowrap">
                  ${quantidade} ${quantidade === 1 ? "produto" : "produtos"}
                </span>
              </div>
              <div class="space-y-3">
                ${cardsProdutos}
              </div>
            </section>
          `;
        });
    })
    .catch(err => console.error(err));
}

// ================= DELETAR =================
function deletarProduto(id) {
  if (!confirm("Excluir produto?")) return;

  fetch(API + "/produto/" + id, {
    method: "DELETE"
  })
    .then(() => listarProdutos())
    .catch(err => console.error(err));
}

// ================= EDITAR =================
function editarProduto(id) {
  fetch(API + "/produto/" + id)
    .then(res => res.json())
    .then(p => {
      document.getElementById("nome").value = p.nome;
      document.getElementById("descricao").value = p.descricao;
      document.getElementById("preco").value = p.preco;
      document.getElementById("estoque").value = p.qtdEstoque;
      document.getElementById("categoria").value = p.categoria?.id;

      window.produtoEditandoId = id;
      window.produtoEditandoImagem = p.imagem || "";
      window.produtoEditandoImagem2 = p.imagem2 || "";
      window.produtoEditandoImagem3 = p.imagem3 || "";
    });
}

// ================= LIMPAR =================
function limparFormulario() {
  document.getElementById("nome").value = "";
  document.getElementById("descricao").value = "";
  document.getElementById("preco").value = "";
  document.getElementById("estoque").value = "";
  document.getElementById("categoria").value = "";
  document.getElementById("imagem").value = "";
  window.produtoEditandoId = null;
  window.produtoEditandoImagem = "";
  window.produtoEditandoImagem2 = "";
  window.produtoEditandoImagem3 = "";
}

// ================= INIT =================
window.onload = () => {
  carregarCategorias();
  listarProdutos();
};
