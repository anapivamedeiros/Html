const API = "http://localhost:8080";

// ================= CARREGAR CATEGORIAS =================

function carregarCategorias() {
  fetch(API + "/categoria")
    .then(res => res.json())
    .then(data => {

      const select = document.getElementById("categoria");

      select.innerHTML = `<option value="">Selecione uma categoria</option>`;

      data.forEach(c => {
        select.innerHTML += `
          <option value="${c.id}">
            ${c.nome}
          </option>
        `;
      });

    })
    .catch(err => {
      console.error("Erro ao carregar categorias:", err);
    });
}

// ================= SALVAR PRODUTO =================

function salvarProduto() {

  const fileInput = document.getElementById("imagem");
  const file = fileInput.files[0];

  const formData = new FormData();

  formData.append("nome", document.getElementById("nome").value);
  formData.append("descricao", document.getElementById("descricao").value);
  formData.append("preco", document.getElementById("preco").value);
  formData.append("qtdEstoque", document.getElementById("estoque").value);
  formData.append("categoria", document.getElementById("categoria").value);

  if (file) {
    formData.append("imagem", file);
  }

  fetch(API + "/produto", {
    method: "POST",
    body: formData
  })
  .then(res => {
    if (!res.ok) throw new Error();
    return res.json();
  })
  .then(() => {
    alert("Produto salvo com sucesso!");
    limparFormulario();
    listarProdutos();
  })
  .catch(err => {
    console.error(err);
    alert("Erro ao salvar produto");
  });
}
// ================= LIMPAR FORM =================

function limparFormulario() {
  document.getElementById("nome").value = "";
  document.getElementById("descricao").value = "";
  document.getElementById("preco").value = "";
  document.getElementById("estoque").value = "";
  document.getElementById("categoria").value = "";
}

// ================= INICIAR =================


function listarProdutos() {
  fetch(API + "/produto")
    .then(res => res.json())
    .then(produtos => {

      const container = document.getElementById("listaProdutos");
      container.innerHTML = "";

      produtos.forEach(p => {
        container.innerHTML += `
  <div class="bg-white p-4 rounded shadow mb-3 flex items-center justify-between gap-4 max-w-2xl mx-auto">

    <!-- IMAGEM -->
    <img src="${p.imagem || 'https://via.placeholder.com/80'}"
         class="w-20 h-20 object-cover rounded">

    <!-- INFO -->
    <div class="flex-1">
      <h3 class="font-bold text-lg">${p.nome}</h3>
      <p class="text-sm text-gray-600">${p.descricao}</p>
      <p class="text-sm">Preço: R$ ${p.preco}</p>
      <p class="text-sm">Estoque: ${p.qtdEstoque}</p>
      <p class="text-xs text-gray-500">
        ${p.categoria?.nome || "Sem categoria"}
      </p>
    </div>

    <!-- BOTÕES -->
    <div class="flex flex-col gap-2">

      <button onclick="editarProduto(${p.id})"
        class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded text-sm">
        Editar
      </button>

      <button onclick="deletarProduto(${p.id})"
        class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">
        Excluir
      </button>

    </div>

  </div>
`;
      });

    })
    .catch(err => console.error(err));
}


function deletarProduto(id) {
  if (!confirm("Tem certeza que deseja excluir?")) return;

  fetch(API + "/produto/" + id, {
    method: "DELETE"
  })
  .then(res => {
    if (!res.ok) throw new Error();
    listarProdutos();
  })
  .catch(err => {
    alert("Erro ao excluir produto");
    console.error(err);
  });
}

function editarProduto(id) {
  fetch(API + "/produto/" + id)
    .then(res => res.json())
    .then(p => {

      document.getElementById("nome").value = p.nome;
      document.getElementById("descricao").value = p.descricao;
      document.getElementById("preco").value = p.preco;
      document.getElementById("estoque").value = p.qtdEstoque;
      document.getElementById("categoria").value = p.categoria?.id;

      // guarda ID para update
      window.produtoEditandoId = id;

    });
}

function salvarProduto() {

  const produto = {
    nome: document.getElementById("nome").value,
    descricao: document.getElementById("descricao").value,
    preco: parseFloat(document.getElementById("preco").value),
    qtdEstoque: parseInt(document.getElementById("estoque").value),
    categoria: {
      id: parseInt(document.getElementById("categoria").value)
    }
  };

  let url = API + "/produto";
  let method = "POST";

  // se estiver editando
  if (window.produtoEditandoId) {
    url = API + "/produto/" + window.produtoEditandoId;
    method = "PUT";
  }

  fetch(url, {
    method: method,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(produto)
  })
  .then(res => {
    if (!res.ok) throw new Error();
    return res.json();
  })
  .then(() => {

    alert("Salvo com sucesso!");
    limparFormulario();
    listarProdutos();

    window.produtoEditandoId = null; // reset

  })
  .catch(err => {
    console.error(err);
    alert("Erro ao salvar produto");
  });
}



window.onload = () => {
  carregarCategorias();
  listarProdutos();
};
