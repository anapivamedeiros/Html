const API = "http://localhost:8080";

if (exigirLogin()) {
  renderizarCarrinho();
}

function moeda(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}

function escaparHtml(texto) {
  return String(texto ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderizarCarrinho() {
  const lista = document.getElementById("listaCarrinho");
  const carrinho = obterCarrinho();

  if (carrinho.length === 0) {
    lista.innerHTML = `<div class="bg-white rounded-xl shadow p-6 text-gray-500">Seu carrinho esta vazio.</div>`;
  } else {
    lista.innerHTML = carrinho.map(item => `
      <div class="bg-white rounded-xl shadow p-4 flex items-center justify-between gap-4">
        <div>
          <h2 class="font-bold">${escaparHtml(item.nome)}</h2>
          <p class="text-sm text-gray-500">Quantidade: ${item.quantidade}</p>
          <p class="text-sm text-gray-500">Unitario: ${moeda(item.preco)}</p>
        </div>
        <div class="text-right">
          <p class="font-bold">${moeda(item.preco * item.quantidade)}</p>
          <button onclick="removerDoCarrinho(${item.id})" class="text-red-500 text-sm font-semibold">Remover</button>
        </div>
      </div>
    `).join("");
  }

  const total = carrinho.reduce((soma, item) => soma + Number(item.preco) * item.quantidade, 0);
  document.getElementById("totalCarrinho").textContent = `Total: ${moeda(total)}`;
}

function removerDoCarrinho(id) {
  salvarCarrinho(obterCarrinho().filter(item => Number(item.id) !== Number(id)));
  renderizarCarrinho();
}

async function confirmarCompra() {
  const usuario = obterUsuarioLogado();
  const carrinho = obterCarrinho();
  const botao = document.getElementById("btnFinalizarCompra");

  if (!usuario || carrinho.length === 0) {
    alert("Adicione produtos ao carrinho antes de finalizar.");
    return;
  }

  const pedido = {
    usuarioId: usuario.id,
    usuarioNome: usuario.nome,
    usuarioEmail: usuario.email,
    enderecoEntrega: document.getElementById("enderecoEntrega").value,
    itens: carrinho.map(item => ({
      produtoId: item.id,
      quantidade: item.quantidade
    }))
  };

  botao.disabled = true;
  botao.textContent = "Finalizando...";

  try {
    const resposta = await fetch(`${API}/pedidos/finalizar`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(pedido)
    });

    if (!resposta.ok) {
      const erro = await resposta.json().catch(() => ({}));
      throw new Error(erro.message || "Nao foi possivel finalizar o pedido.");
    }

    salvarCarrinho([]);
    alert("Compra finalizada com sucesso!");
    window.location.href = "pedidos.html";
  } catch (erro) {
    alert(erro.message);
  } finally {
    botao.disabled = false;
    botao.textContent = "Finalizar compra";
  }
}
