package br.com.docepatinha.petshop.dto;

import java.util.ArrayList;
import java.util.List;

public class PedidoRequest {

  private Long usuarioId;
  private String usuarioNome;
  private List<ItemPedidoRequest> itens = new ArrayList<>();

  public Long getUsuarioId() {
    return usuarioId;
  }

  public void setUsuarioId(Long usuarioId) {
    this.usuarioId = usuarioId;
  }

  public String getUsuarioNome() {
    return usuarioNome;
  }

  public void setUsuarioNome(String usuarioNome) {
    this.usuarioNome = usuarioNome;
  }

  public List<ItemPedidoRequest> getItens() {
    return itens;
  }

  public void setItens(List<ItemPedidoRequest> itens) {
    this.itens = itens;
  }
}
