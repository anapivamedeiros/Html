package br.com.docepatinha.petshop.repository;

import br.com.docepatinha.petshop.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
}
