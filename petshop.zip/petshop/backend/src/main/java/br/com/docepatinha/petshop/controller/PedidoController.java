package br.com.docepatinha.petshop.controller;

import br.com.docepatinha.petshop.dto.PedidoRequest;
import br.com.docepatinha.petshop.model.Pedido;
import br.com.docepatinha.petshop.service.PedidoService;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

  private final PedidoService pedidoService;

  public PedidoController(PedidoService pedidoService) {
    this.pedidoService = pedidoService;
  }

  @GetMapping
  public List<Pedido> listarTodos() {
    return pedidoService.listarTodos();
  }

  @GetMapping("/usuario/{usuarioId}")
  public List<Pedido> listarPorUsuario(@PathVariable Long usuarioId) {
    return pedidoService.listarPorUsuario(usuarioId);
  }

  @PostMapping("/finalizar")
  public ResponseEntity<?> finalizar(@RequestBody PedidoRequest request) {
    try {
      return ResponseEntity.status(HttpStatus.CREATED).body(pedidoService.finalizar(request));
    } catch (IllegalArgumentException erro) {
      return ResponseEntity.badRequest().body(erro.getMessage());
    }
  }
}
