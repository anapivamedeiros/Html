package br.com.docepatinha.petshop.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "usuarios")
public class Usuario {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String nome;

  private String email;

  private String senha;

  private String perfil;

  private String endereco;

  private String bairro;

  private String complemento;

  private String cep;

  private String cidade;

  private String estado;

  @Column(columnDefinition = "LONGTEXT")
  private String foto;

  @Column(name = "data_cadastro")
  private LocalDateTime dataCadastro;

  public Long getId() {
    return id;
  }

  public String getNome() {
    return nome;
  }

  public String getEmail() {
    return email;
  }

  public String getSenha() {
    return senha;
  }

  public String getPerfil() {
    return perfil;
  }

  public String getEndereco() {
    return endereco;
  }

  public String getBairro() {
    return bairro;
  }

  public String getComplemento() {
    return complemento;
  }

  public String getCep() {
    return cep;
  }

  public String getCidade() {
    return cidade;
  }

  public String getEstado() {
    return estado;
  }

  public String getFoto() {
    return foto;
  }

  public LocalDateTime getDataCadastro() {
    return dataCadastro;
  }
}
