package br.com.docepatinha.petshop.repository;

import br.com.docepatinha.petshop.model.Pedido;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

  List<Pedido> findByUsuarioIdOrderByDataCriacaoDesc(Long usuarioId);

  List<Pedido> findAllByOrderByDataCriacaoDesc();
}
