package br.com.docepatinha.petshop.repository;

import br.com.docepatinha.petshop.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
}
