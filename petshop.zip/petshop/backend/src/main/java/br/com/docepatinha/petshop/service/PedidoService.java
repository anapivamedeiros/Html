package br.com.docepatinha.petshop.service;

import br.com.docepatinha.petshop.dto.ItemPedidoRequest;
import br.com.docepatinha.petshop.dto.PedidoRequest;
import br.com.docepatinha.petshop.model.ItemPedido;
import br.com.docepatinha.petshop.model.Pedido;
import br.com.docepatinha.petshop.model.PedidoStatus;
import br.com.docepatinha.petshop.model.Produto;
import br.com.docepatinha.petshop.repository.PedidoRepository;
import br.com.docepatinha.petshop.repository.ProdutoRepository;
import jakarta.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class PedidoService {

  private final PedidoRepository pedidoRepository;
  private final ProdutoRepository produtoRepository;

  public PedidoService(PedidoRepository pedidoRepository, ProdutoRepository produtoRepository) {
    this.pedidoRepository = pedidoRepository;
    this.produtoRepository = produtoRepository;
  }

  public List<Pedido> listarTodos() {
    return pedidoRepository.findAllByOrderByDataCriacaoDesc();
  }

  public List<Pedido> listarPorUsuario(Long usuarioId) {
    return pedidoRepository.findByUsuarioIdOrderByDataCriacaoDesc(usuarioId);
  }

  @Transactional
  public Pedido finalizar(PedidoRequest request) {
    if (request.getUsuarioId() == null || request.getItens() == null || request.getItens().isEmpty()) {
      throw new IllegalArgumentException("Pedido sem usuario ou sem itens.");
    }

    Pedido pedido = new Pedido();
    pedido.setUsuarioId(request.getUsuarioId());
    pedido.setUsuarioNome(request.getUsuarioNome());
    pedido.setDataCriacao(LocalDateTime.now());
    pedido.setStatus(PedidoStatus.FINALIZADO);

    BigDecimal total = BigDecimal.ZERO;

    for (ItemPedidoRequest itemRequest : request.getItens()) {
      Produto produto = produtoRepository.findById(itemRequest.getProdutoId())
          .orElseThrow(() -> new IllegalArgumentException("Produto nao encontrado: " + itemRequest.getProdutoId()));

      int quantidade = itemRequest.getQuantidade() == null ? 0 : itemRequest.getQuantidade();
      if (quantidade <= 0) {
        throw new IllegalArgumentException("Quantidade invalida para o produto " + produto.getNome());
      }

      if (produto.getQtdEstoque() != null && produto.getQtdEstoque() < quantidade) {
        throw new IllegalArgumentException("Estoque insuficiente para o produto " + produto.getNome());
      }

      BigDecimal preco = produto.getPreco() == null ? BigDecimal.ZERO : produto.getPreco();
      BigDecimal subtotal = preco.multiply(BigDecimal.valueOf(quantidade));

      ItemPedido item = new ItemPedido();
      item.setProdutoId(produto.getId());
      item.setNomeProduto(produto.getNome());
      item.setPrecoUnitario(preco);
      item.setQuantidade(quantidade);
      item.setSubtotal(subtotal);

      pedido.adicionarItem(item);
      produto.baixarEstoque(quantidade);
      total = total.add(subtotal);
    }

    pedido.setTotal(total);
    return pedidoRepository.save(pedido);
  }
}
