package br.com.docepatinha.petshop.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name = "produto")
public class Produto {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String nome;

  private BigDecimal preco;

  @Column(name = "qtd_estoque")
  private Integer qtdEstoque;

  public Long getId() {
    return id;
  }

  public String getNome() {
    return nome;
  }

  public BigDecimal getPreco() {
    return preco;
  }

  public Integer getQtdEstoque() {
    return qtdEstoque;
  }

  public void baixarEstoque(Integer quantidade) {
    this.qtdEstoque = (this.qtdEstoque == null ? 0 : this.qtdEstoque) - quantidade;
  }
}
