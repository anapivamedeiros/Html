package br.com.docepatinha.petshop.model;

public enum PedidoStatus {
  FINALIZADO
}
