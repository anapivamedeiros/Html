CREATE DATABASE IF NOT EXISTS petshop;
USE petshop;

CREATE TABLE IF NOT EXISTS pedido (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  usuario_id BIGINT NOT NULL,
  usuario_nome VARCHAR(120),
  data_criacao DATETIME NOT NULL,
  status VARCHAR(30) NOT NULL,
  total DECIMAL(10, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS item_pedido (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  pedido_id BIGINT NOT NULL,
  produto_id BIGINT NOT NULL,
  nome_produto VARCHAR(120) NOT NULL,
  preco_unitario DECIMAL(10, 2) NOT NULL,
  quantidade INT NOT NULL,
  subtotal DECIMAL(10, 2) NOT NULL,
  CONSTRAINT fk_item_pedido_pedido
    FOREIGN KEY (pedido_id) REFERENCES pedido(id)
);
