const API = "http://localhost:8080/categoria";

let idEditando = null;

if (typeof exigirAdmin === "function") {
  exigirAdmin();
}

// 🔹 LISTAR
function listar() {
  const lista = document.getElementById("lista");

  if (!lista) return;

  fetch(API)
    .then(res => res.json())
    .then(dados => {

      lista.innerHTML = "";

      dados.forEach(c => {
        lista.innerHTML += `
          <div class="bg-white p-3 rounded shadow flex justify-between items-center">

            <div>
              <strong>${c.nome}</strong><br>
              <span class="text-sm text-gray-600">${c.descricao}</span>
            </div>

            <div class="space-x-2">

              <button onclick="editar(${c.id}, '${c.nome}', '${c.descricao}')"
                class="bg-yellow-400 px-2 py-1 rounded">
                Editar
              </button>

              <button onclick="excluir(${c.id})"
                class="bg-red-500 text-white px-2 py-1 rounded">
                Excluir
              </button>

            </div>

          </div>
        `;
      });

    })
    .catch(err => console.error(err));
}

// 🔹 SALVAR (CREATE / UPDATE)
function salvar() {

  const nome = document.getElementById("nome").value;
  const descricao = document.getElementById("descricao").value;

  if (!nome || !descricao) {
    alert("Preencha todos os campos!");
    return;
  }

  const metodo = idEditando ? "PUT" : "POST";
  const url = idEditando ? `${API}/${idEditando}` : API;

  fetch(url, {
    method: metodo,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ nome, descricao })
  })
  .then(() => {
    limpar();
    listar();
  })
  .catch(err => console.error(err));
}

// 🔹 EDITAR
function editar(id, nome, descricao) {
  document.getElementById("nome").value = nome;
  document.getElementById("descricao").value = descricao;
  idEditando = id;
}

// 🔹 EXCLUIR
function excluir(id) {
  if (!confirm("Deseja excluir esta categoria?")) return;

  fetch(`${API}/${id}`, {
    method: "DELETE"
  })
  .then(() => listar())
  .catch(err => console.error(err));
}

// 🔹 LIMPAR
function limpar() {
  document.getElementById("nome").value = "";
  document.getElementById("descricao").value = "";
  idEditando = null;
}

// 🔹 INICIALIZAÇÃO
window.onload = listar;
