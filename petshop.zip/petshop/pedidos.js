const API = "http://localhost:8080";

if (exigirLogin()) {
  carregarPedidos();
}

function moeda(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}

function dataPedido(valor) {
  if (!valor) {
    return "";
  }

  return new Date(valor).toLocaleString("pt-BR");
}

function normalizarPedido(pedido) {
  const itens = (pedido.itens || []).map(item => ({
    nome: item.nomeProduto ?? item.nome,
    quantidade: item.quantidade,
    preco: Number(item.precoUnitario ?? item.preco ?? 0)
  }));

  return {
    id: pedido.idPedido ?? pedido.id,
    usuarioId: pedido.usuario?.id ?? pedido.usuarioId,
    usuarioNome: pedido.usuario?.nome ?? pedido.usuarioNome,
    data: dataPedido(pedido.dataPedido) || pedido.data,
    status: pedido.status,
    total: Number(pedido.valorTotal ?? pedido.total ?? 0),
    itens
  };
}

async function carregarPedidos() {
  const usuario = obterUsuarioLogado();

  try {
    const url = usuario.role === "ADMIN"
      ? `${API}/pedidos`
      : `${API}/pedidos/usuario/${usuario.id}`;

    const resposta = await fetch(url);
    if (!resposta.ok) {
      throw new Error("Erro ao buscar pedidos.");
    }

    const pedidos = await resposta.json();
    renderizarPedidos(pedidos.map(normalizarPedido));
  } catch (erro) {
    const pedidosLocais = obterPedidos().filter(pedido =>
      usuario.role === "ADMIN" || pedido.usuarioId === usuario.id
    );
    renderizarPedidos(pedidosLocais.map(normalizarPedido));
  }
}

function renderizarPedidos(pedidos) {
  const lista = document.getElementById("listaPedidos");

  if (pedidos.length === 0) {
    lista.innerHTML = `<div class="bg-white rounded-xl shadow p-6 text-gray-500">Nenhum pedido encontrado.</div>`;
    return;
  }

  lista.innerHTML = pedidos.map(pedido => `
    <article class="bg-white rounded-xl shadow p-5 border border-pink-100">
      <div class="flex justify-between gap-4 flex-wrap">
        <div>
          <h2 class="font-bold text-lg">Pedido #${pedido.id}</h2>
          <p class="text-sm text-gray-500">${pedido.data} - ${pedido.status}</p>
          <p class="text-sm text-gray-500">${pedido.usuarioNome || ""}</p>
        </div>
        <strong>${moeda(pedido.total)}</strong>
      </div>
      <ul class="mt-4 text-sm text-gray-600 space-y-1">
        ${pedido.itens.map(item => `<li>${item.quantidade}x ${item.nome} - ${moeda(item.preco * item.quantidade)}</li>`).join("")}
      </ul>
    </article>
  `).join("");
}
