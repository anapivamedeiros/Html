document.getElementById("formCadastro").addEventListener("submit", event => {
  event.preventDefault();

  try {
    const usuario = registrarUsuario({
      nome: document.getElementById("nome").value,
      email: document.getElementById("email").value,
      senha: document.getElementById("senha").value,
      role: "USER"
    });

    salvarSessao(usuario);
    window.location.href = "catalogo.html";
  } catch (erro) {
    alert(erro.message);
  }
});
