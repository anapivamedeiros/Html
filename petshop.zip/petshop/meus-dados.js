const usuario = obterUsuarioLogado();

if (!exigirLogin()) {
  throw new Error("Usuario nao autenticado.");
}

document.getElementById("nome").value = usuario.nome;
document.getElementById("email").value = usuario.email;

document.getElementById("formMeusDados").addEventListener("submit", event => {
  event.preventDefault();

  try {
    atualizarUsuario(usuario.id, {
      nome: document.getElementById("nome").value,
      email: document.getElementById("email").value,
      senha: document.getElementById("senha").value,
      role: usuario.role
    });

    alert("Dados atualizados.");
    window.location.href = "catalogo.html";
  } catch (erro) {
    alert(erro.message);
  }
});
