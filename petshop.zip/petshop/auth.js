const AUTH_USERS_KEY = "docePatinhaUsuarios";
const AUTH_SESSION_KEY = "docePatinhaSessao";
const AUTH_CART_KEY = "docePatinhaCarrinho";
const AUTH_ORDERS_KEY = "docePatinhaPedidos";

function seedUsuariosPadrao() {
  const usuarios = JSON.parse(localStorage.getItem(AUTH_USERS_KEY) || "[]");

  if (usuarios.length > 0) {
    return usuarios;
  }

  const iniciais = [
    {
      id: 1,
      nome: "Administrador",
      email: "admin@docepatinha.com",
      senha: "admin123",
      role: "ADMIN"
    },
    {
      id: 2,
      nome: "Cliente",
      email: "cliente@docepatinha.com",
      senha: "user123",
      role: "USER"
    }
  ];

  localStorage.setItem(AUTH_USERS_KEY, JSON.stringify(iniciais));
  return iniciais;
}

function obterUsuarios() {
  return seedUsuariosPadrao();
}

function salvarUsuarios(usuarios) {
  localStorage.setItem(AUTH_USERS_KEY, JSON.stringify(usuarios));
}

function obterUsuarioLogado() {
  const sessao = JSON.parse(localStorage.getItem(AUTH_SESSION_KEY) || "null");

  if (!sessao) {
    return null;
  }

  return obterUsuarios().find(usuario => usuario.id === sessao.id) || null;
}

function salvarSessao(usuario) {
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    role: usuario.role
  }));
}

function fazerLogin(email, senha) {
  const usuario = obterUsuarios().find(item =>
    item.email.toLowerCase() === String(email).toLowerCase() &&
    item.senha === senha
  );

  if (!usuario) {
    return false;
  }

  salvarSessao(usuario);
  return true;
}

function fazerLogout() {
  localStorage.removeItem(AUTH_SESSION_KEY);
  window.location.href = "login.html";
}

function usuarioEhAdmin() {
  return obterUsuarioLogado()?.role === "ADMIN";
}

function exigirLogin() {
  if (!obterUsuarioLogado()) {
    window.location.href = "login.html";
    return false;
  }

  return true;
}

function exigirAdmin() {
  const usuario = obterUsuarioLogado();

  if (!usuario) {
    window.location.href = "login.html";
    return false;
  }

  if (usuario.role !== "ADMIN") {
    alert("Acesso restrito ao perfil ADMIN.");
    window.location.href = "catalogo.html";
    return false;
  }

  return true;
}

function registrarUsuario(dados) {
  const usuarios = obterUsuarios();
  const email = String(dados.email || "").trim().toLowerCase();

  if (usuarios.some(usuario => usuario.email.toLowerCase() === email)) {
    throw new Error("Este e-mail ja esta cadastrado.");
  }

  const novoUsuario = {
    id: Date.now(),
    nome: String(dados.nome || "").trim(),
    email,
    senha: String(dados.senha || ""),
    role: dados.role === "ADMIN" ? "ADMIN" : "USER"
  };

  usuarios.push(novoUsuario);
  salvarUsuarios(usuarios);
  return novoUsuario;
}

function atualizarUsuario(id, dados) {
  const usuarios = obterUsuarios();
  const indice = usuarios.findIndex(usuario => usuario.id === Number(id));

  if (indice < 0) {
    return null;
  }

  const email = String(dados.email || "").trim().toLowerCase();
  const emailEmUso = usuarios.some(usuario =>
    usuario.id !== Number(id) && usuario.email.toLowerCase() === email
  );

  if (emailEmUso) {
    throw new Error("Este e-mail ja esta em uso.");
  }

  usuarios[indice] = {
    ...usuarios[indice],
    nome: String(dados.nome || "").trim(),
    email,
    senha: dados.senha ? String(dados.senha) : usuarios[indice].senha,
    role: dados.role === "ADMIN" ? "ADMIN" : "USER"
  };

  salvarUsuarios(usuarios);

  const logado = obterUsuarioLogado();
  if (logado?.id === Number(id)) {
    salvarSessao(usuarios[indice]);
  }

  return usuarios[indice];
}

function removerUsuario(id) {
  const usuarioAtual = obterUsuarioLogado();

  if (usuarioAtual?.id === Number(id)) {
    throw new Error("Voce nao pode excluir o proprio usuario logado.");
  }

  salvarUsuarios(obterUsuarios().filter(usuario => usuario.id !== Number(id)));
}

function obterCarrinho() {
  return JSON.parse(localStorage.getItem(AUTH_CART_KEY) || "[]");
}

function salvarCarrinho(itens) {
  localStorage.setItem(AUTH_CART_KEY, JSON.stringify(itens));
}

function adicionarAoCarrinho(produto, quantidade = 1) {
  if (!exigirLogin()) {
    return;
  }

  const id = produto.idProduto ?? produto.id;
  const carrinho = obterCarrinho();
  const item = carrinho.find(produtoCarrinho => Number(produtoCarrinho.id) === Number(id));

  if (item) {
    item.quantidade += quantidade;
  } else {
    carrinho.push({
      id,
      nome: produto.nome,
      preco: Number(produto.preco || 0),
      imagem: produto.imagem || "",
      quantidade
    });
  }

  salvarCarrinho(carrinho);
  alert("Produto adicionado ao carrinho.");
}

function obterPedidos() {
  return JSON.parse(localStorage.getItem(AUTH_ORDERS_KEY) || "[]");
}

function salvarPedidos(pedidos) {
  localStorage.setItem(AUTH_ORDERS_KEY, JSON.stringify(pedidos));
}

function finalizarCompra() {
  const usuario = obterUsuarioLogado();
  const carrinho = obterCarrinho();

  if (!usuario || carrinho.length === 0) {
    return null;
  }

  const pedido = {
    id: Date.now(),
    usuarioId: usuario.id,
    usuarioNome: usuario.nome,
    data: new Date().toLocaleString("pt-BR"),
    status: "Finalizado",
    itens: carrinho,
    total: carrinho.reduce((soma, item) => soma + Number(item.preco) * item.quantidade, 0)
  };

  const pedidos = obterPedidos();
  pedidos.push(pedido);
  salvarPedidos(pedidos);
  salvarCarrinho([]);
  return pedido;
}

function irPosLogin() {
  window.location.href = usuarioEhAdmin() ? "configuracao.html" : "catalogo.html";
}

function renderizarAreaAutenticada() {
  const header = document.querySelector("header");

  if (!header || document.getElementById("authHeaderArea")) {
    return;
  }

  const usuario = obterUsuarioLogado();
  const configuracao = header.querySelector('a[href="configuracao.html"]');

  if (configuracao) {
    configuracao.style.display = "none";
    configuracao.title = "Configurações";
  }

  const area = document.createElement("div");
  area.id = "authHeaderArea";
  area.className = "flex items-center gap-3 text-sm font-semibold";

  if (!usuario) {
    area.innerHTML = `
      <a href="login.html" class="text-pink-600 hover:text-pink-700">Login</a>
      <a href="cadastro.html" class="bg-yellow-300 hover:bg-yellow-500 text-white px-4 py-2 rounded-lg transition">Cadastro</a>
    `;
  } else {
    const linkAdmin = usuario.role === "ADMIN"
      ? `<a href="configuracao.html" title="Configurações" aria-label="Configurações" class="flex items-center justify-center">
          <img src="./imgs/configuracoes.png" class="w-7 h-7 hover:scale-110 transition duration-300" alt="Configurações">
        </a>`
      : "";

    area.innerHTML = `
      ${linkAdmin}
      <a href="carrinho.html" title="Carrinho" aria-label="Carrinho" class="text-gray-700 hover:text-pink-600 text-xl leading-none">🛒</a>
      <a href="pedidos.html" class="text-gray-700 hover:text-pink-600">Pedidos</a>
      <a href="meus-dados.html" class="text-gray-700 hover:text-pink-600">${usuario.nome}</a>
      <button type="button" onclick="fazerLogout()" class="text-red-500 hover:text-red-600">Sair</button>
    `;
  }

  header.appendChild(area);
}

document.addEventListener("DOMContentLoaded", () => {
  seedUsuariosPadrao();
  renderizarAreaAutenticada();
});
