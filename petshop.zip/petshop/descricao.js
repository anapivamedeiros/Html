const API = "http://localhost:8080";

const params = new URLSearchParams(window.location.search);

const id = params.get("id");

fetch(API + "/produto/" + id)
  .then(res => res.json())
  .then(p => {

    document.getElementById("produto").innerHTML = `

      <!-- IMAGEM -->
      <div>
        <img
          src="http://localhost:8080/uploads/${p.imagem}"
          class="w-full h-[500px] object-cover rounded-2xl"
        >
      </div>

      <!-- INFO -->
      <div class="flex flex-col justify-center">

        <span class="text-sm text-pink-500 font-bold uppercase">
          ${p.categoria?.nome || ""}
        </span>

        <h1 class="text-4xl font-bold mt-2">
          ${p.nome}
        </h1>

        <p class="text-gray-600 mt-4 text-lg">
          ${p.descricao}
        </p>

        <p class="text-3xl font-bold text-pink-600 mt-6">
          R$ ${p.preco}
        </p>

        <p class="text-gray-500 mt-3">
          Estoque: ${p.qtdEstoque}
        </p>

        <button
          class="mt-8 bg-pink-400 hover:bg-pink-500 text-white py-3 rounded-xl text-lg font-bold transition">
          Comprar
        </button>

      </div>

    `;
  });