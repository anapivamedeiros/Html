const API = "http://localhost:8080";
const IMAGEM_PADRAO = "https://placehold.co/500x500";

function montarUrlImagem(imagem) {
  if (!imagem || imagem === "null" || imagem === "undefined") {
    return IMAGEM_PADRAO;
  }

  const caminho = String(imagem).trim().replace(/^["']|["']$/g, "");

  if (
    caminho.startsWith("http://") ||
    caminho.startsWith("https://") ||
    caminho.startsWith("data:") ||
    caminho.startsWith("blob:")
  ) {
    return caminho;
  }

  if (caminho.startsWith("/uploads/")) {
    return `${API}${caminho}`;
  }

  if (caminho.startsWith("uploads/")) {
    return `${API}/${caminho}`;
  }

  const nomeArquivo = caminho.split("\\").pop().split("/").pop();
  return `${API}/uploads/${nomeArquivo}`;
}

const params = new URLSearchParams(window.location.search);
const id = params.get("id");

fetch(`${API}/produto/${id}`)
  .then(res => res.json())
  .then(p => {

    let imagem = montarUrlImagem(p.imagem);

    document.getElementById("produto").innerHTML = `
      <!-- IMAGEM -->
      <div>
        <img
          src="${imagem}"
          class="w-full h-[500px] object-cover rounded-2xl"
          onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'"
        >
      </div>

      <!-- INFO -->
      <div class="flex flex-col justify-center">

        <span class="text-sm text-pink-500 font-bold uppercase">
          ${p.categoria?.nome || ""}
        </span>

        <h1 class="text-4xl font-bold mt-2">
          ${p.nome}
        </h1>

        <p class="text-gray-600 mt-4 text-lg">
          ${p.descricao || ""}
        </p>

        <p class="text-3xl font-bold text-pink-600 mt-6">
          R$ ${Number(p.preco).toFixed(2)}
        </p>

        <p class="text-gray-500 mt-3">
          Estoque: ${p.qtdEstoque ?? 0}
        </p>

        <button class="mt-8 bg-pink-400 hover:bg-pink-500 text-white py-3 rounded-xl text-lg font-bold transition">
          Comprar
        </button>

      </div>
    `;
  })
  .catch(err => console.error("Erro produto:", err));
