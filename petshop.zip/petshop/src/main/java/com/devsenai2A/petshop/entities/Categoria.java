package com.devsenai2A.petshop.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "categoria")

public class Categoria {

@Id()
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "id_categoria")
private Long id;

@Column(name = "nome", length = 100)
private String nome;

@Column(name = "descricao", columnDefinition = "TEXT")
private String descricao;

@Column(name = "ativo")
private Boolean ativo = true;
//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)


public Categoria() {}

public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getDescricao() {
	return descricao;
}

public void setDescricao(String descricao) {
	this.descricao = descricao;
}

public Boolean getAtivo() {
	return ativo;
}

public void setAtivo(Boolean ativo) {
	this.ativo = ativo;
}
}
