package com.devsenai2A.petshop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devsenai2A.petshop.entities.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findAllByOrderByDataPedidoDesc();

    List<Pedido> findByUsuario_IdOrderByDataPedidoDesc(Long usuarioId);
}
