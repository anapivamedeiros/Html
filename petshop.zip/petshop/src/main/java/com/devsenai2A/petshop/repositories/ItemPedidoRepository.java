package com.devsenai2A.petshop.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devsenai2A.petshop.entities.ItemPedido;

public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long> {
}
