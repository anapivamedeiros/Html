package com.devsenai2A.petshop.controllers;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.devsenai2A.petshop.entities.Categoria;
import com.devsenai2A.petshop.entities.Produto;
import com.devsenai2A.petshop.repositories.CategoriaRepository;
import com.devsenai2A.petshop.services.ProdutoService;

@RestController
@RequestMapping("/produto")
@CrossOrigin("*")
public class ProdutoController {

    private static final Path UPLOAD_DIR = Paths.get("uploads").toAbsolutePath().normalize();

    @Autowired
    private ProdutoService service;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @PostMapping
    public Produto salvar(@RequestBody Map<String, Object> dados) {
        return service.salvar(montarProduto(dados));
    }

    @GetMapping
    public List<Produto> listarTodos() {
        return service.listarTodos();
    }

    // Endpoint: busca produtos ativos pelo nome
    @GetMapping("/buscar")
    public List<Produto> buscarPorNome(@RequestParam String nome) {
        return service.buscarPorNome(nome);
    }

    // Endpoint: todos os produtos ativos de uma categoria
    @GetMapping("/categoria/{idCategoria}")
    public List<Produto> getProdutosByCategoria(@PathVariable Long idCategoria) {
        return service.getProdutosPorCategoria(idCategoria);
    }

    @GetMapping("/{id}")
    public Produto buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Produto atualizar(@PathVariable Long id, @RequestBody Map<String, Object> dados) {
        return service.atualizar(id, montarProduto(dados));
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        service.deletar(id);
    }
    
    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file) throws Exception {
        if (file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Arquivo vazio");
        }

        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Envie um arquivo de imagem");
        }

        Files.createDirectories(UPLOAD_DIR);

        String arquivoOriginal = file.getOriginalFilename() == null ? "imagem" : file.getOriginalFilename();
        String nomeOriginal = Paths.get(arquivoOriginal).getFileName().toString();
        String nomeSeguro = nomeOriginal.replaceAll("[^a-zA-Z0-9._-]", "_");
        String nome = UUID.randomUUID() + "_" + nomeSeguro;

        Path path = UPLOAD_DIR.resolve(nome);
        Files.copy(file.getInputStream(), path);

        return ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/uploads/")
                .path(nome)
                .toUriString();
    }

    private Produto montarProduto(Map<String, Object> dados) {
        Produto produto = new Produto();

        produto.setNome(texto(dados.get("nome")));
        produto.setDescricao(texto(dados.get("descricao")));
        produto.setPreco(decimal(dados.get("preco")));
        produto.setPrecoDesconto(decimal(dados.get("precoDesconto")));
        produto.setImagem(texto(dados.get("imagem")));
        produto.setImagem2(texto(dados.get("imagem2")));
        produto.setImagem3(texto(dados.get("imagem3")));
        produto.setSku(texto(dados.get("sku")));
        produto.setQtdEstoque(inteiro(dados.get("qtdEstoque")));
        produto.setAtivo(booleano(dados.get("ativo")));
        produto.setCategoria(categoria(dados));

        return produto;
    }

    private Categoria categoria(Map<String, Object> dados) {
        Object valor = dados.get("categoria");
        if (valor == null) {
            valor = dados.get("categoriaId");
        }
        if (valor == null) {
            valor = dados.get("idCategoria");
        }
        if (valor == null) {
            valor = dados.get("id_categoria");
        }
        if (valor == null) {
            valor = dados.get("categoria_id");
        }
        if (valor == null || valor.toString().isBlank()) {
            return null;
        }

        Long id = null;
        if (valor instanceof Number numero) {
            id = numero.longValue();
        } else if (valor instanceof String texto) {
            id = Long.valueOf(texto);
        } else if (valor instanceof Map<?, ?> mapa) {
            Object idValor = mapa.get("id");
            if (idValor == null) {
                idValor = mapa.get("id_categoria");
            }
            if (idValor instanceof Number numero) {
                id = numero.longValue();
            } else if (idValor instanceof String texto && !texto.isBlank()) {
                id = Long.valueOf(texto);
            }
        }

        if (id == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Categoria invalida");
        }

        Long idCategoria = id;
        return categoriaRepository.findById(idCategoria)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Categoria nao encontrada: " + idCategoria));
    }

    private String texto(Object valor) {
        return valor == null ? null : valor.toString();
    }

    private Double decimal(Object valor) {
        if (valor == null || valor.toString().isBlank()) {
            return null;
        }
        if (valor instanceof Number numero) {
            return numero.doubleValue();
        }
        return Double.valueOf(valor.toString().replace(",", "."));
    }

    private Integer inteiro(Object valor) {
        if (valor == null || valor.toString().isBlank()) {
            return null;
        }
        if (valor instanceof Number numero) {
            return numero.intValue();
        }
        return Integer.valueOf(valor.toString());
    }

    private Boolean booleano(Object valor) {
        if (valor == null || valor.toString().isBlank()) {
            return true;
        }
        if (valor instanceof Boolean bool) {
            return bool;
        }
        return Boolean.valueOf(valor.toString());
    }
}
