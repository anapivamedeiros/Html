package com.devsenai2A.petshop;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig {

    // CORS
    @Bean
    public WebMvcConfigurer corsConfigurer() {

        return new WebMvcConfigurer() {

            @Override
            public void addCorsMappings(CorsRegistry registry) {

                registry.addMapping("/**")
                        .allowedOriginPatterns("*")
                        .allowedHeaders("*")
                        .allowedMethods("HEAD", "PUT", "POST", "PATCH", "DELETE", "GET");
            }

            // 📸 LIBERAR IMAGENS
            @Override
            public void addResourceHandlers(ResourceHandlerRegistry registry) {
                Path uploadPath = Paths.get("uploads").toAbsolutePath().normalize();

                registry.addResourceHandler("/uploads/**")
                        .addResourceLocations(uploadPath.toUri().toString());
            }
        };
    }
}
