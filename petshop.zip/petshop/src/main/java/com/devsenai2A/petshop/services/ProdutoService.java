package com.devsenai2A.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2A.petshop.entities.Produto;
import com.devsenai2A.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    public Produto salvar(Produto produto) {
        return repository.save(produto);
    }

    public List<Produto> listarTodos() {
        return repository.findAll();
    }

    public Produto buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));
    }

    public Produto atualizar(Long id, Produto produtoAtualizado) {
        Produto produto = buscarPorId(id);

        produto.setNome(produtoAtualizado.getNome());
        produto.setDescricao(produtoAtualizado.getDescricao());
        produto.setPreco(produtoAtualizado.getPreco());
        produto.setPrecoDesconto(produtoAtualizado.getPrecoDesconto());
        produto.setImagem(produtoAtualizado.getImagem());
        produto.setImagem2(produtoAtualizado.getImagem2());
        produto.setImagem3(produtoAtualizado.getImagem3());
        produto.setSku(produtoAtualizado.getSku());
        produto.setQtdEstoque(produtoAtualizado.getQtdEstoque());
        produto.setAtivo(produtoAtualizado.getAtivo());
        produto.setCategoria(produtoAtualizado.getCategoria());

        return repository.save(produto);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }

    // Retorna todos os produtos ativos de uma categoria
    public List<Produto> getProdutosPorCategoria(Long idCategoria) {
        return repository.findByCategoriaIdAndAtivoTrue(idCategoria);
    }

    // Retorna todos os produtos ativos que tenham o texto buscado no nome
    public List<Produto> buscarPorNome(String nome) {
        if (nome == null || nome.isBlank()) {
            return repository.findAll();
        }
        return repository.findByNomeContainingIgnoreCaseAndAtivoTrue(nome);
    }
}
