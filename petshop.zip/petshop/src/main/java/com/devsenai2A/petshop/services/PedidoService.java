package com.devsenai2A.petshop.services;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.devsenai2A.petshop.dtos.ItemPedidoRequest;
import com.devsenai2A.petshop.dtos.PedidoRequest;
import com.devsenai2A.petshop.entities.ItemPedido;
import com.devsenai2A.petshop.entities.Pedido;
import com.devsenai2A.petshop.entities.Produto;
import com.devsenai2A.petshop.entities.Usuario;
import com.devsenai2A.petshop.repositories.PedidoRepository;
import com.devsenai2A.petshop.repositories.ProdutoRepository;
import com.devsenai2A.petshop.repositories.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final ProdutoRepository produtoRepository;
    private final UsuarioRepository usuarioRepository;

    public PedidoService(PedidoRepository pedidoRepository, ProdutoRepository produtoRepository,
            UsuarioRepository usuarioRepository) {
        this.pedidoRepository = pedidoRepository;
        this.produtoRepository = produtoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public List<Pedido> listarTodos() {
        return pedidoRepository.findAllByOrderByDataPedidoDesc();
    }

    public List<Pedido> listarPorUsuario(Long usuarioId) {
        return pedidoRepository.findByUsuario_IdOrderByDataPedidoDesc(usuarioId);
    }

    @Transactional
    public Pedido finalizar(PedidoRequest request) {
        if (request.getItens() == null || request.getItens().isEmpty()) {
            throw new IllegalArgumentException("Adicione produtos ao carrinho antes de finalizar.");
        }

        Usuario usuario = obterOuCriarUsuario(request);

        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setDataPedido(LocalDateTime.now());
        pedido.setStatus("FINALIZADO");
        pedido.setEnderecoEntrega(montarEnderecoEntrega(request, usuario));

        BigDecimal total = BigDecimal.ZERO;

        for (ItemPedidoRequest itemRequest : request.getItens()) {
            Produto produto = produtoRepository.findById(itemRequest.getProdutoId())
                    .orElseThrow(() -> new IllegalArgumentException("Produto nao encontrado: " + itemRequest.getProdutoId()));

            int quantidade = itemRequest.getQuantidade() == null ? 0 : itemRequest.getQuantidade();
            if (quantidade <= 0) {
                throw new IllegalArgumentException("Quantidade invalida para " + produto.getNome());
            }

            Integer estoque = produto.getQtdEstoque();
            if (estoque != null && estoque < quantidade) {
                throw new IllegalArgumentException("Estoque insuficiente para " + produto.getNome());
            }

            BigDecimal precoUnitario = BigDecimal.valueOf(produto.getPreco() == null ? 0 : produto.getPreco());
            total = total.add(precoUnitario.multiply(BigDecimal.valueOf(quantidade)));

            ItemPedido item = new ItemPedido();
            item.setProduto(produto);
            item.setNomeProduto(produto.getNome());
            item.setQuantidade(quantidade);
            item.setPrecoUnitario(precoUnitario);
            pedido.adicionarItem(item);

            if (estoque != null) {
                produto.setQtdEstoque(estoque - quantidade);
            }
        }

        pedido.setValorTotal(total);
        return pedidoRepository.save(pedido);
    }

    private Usuario obterOuCriarUsuario(PedidoRequest request) {
        if (request.getUsuarioId() != null) {
            return usuarioRepository.findById(request.getUsuarioId())
                    .orElseGet(() -> criarUsuario(request));
        }

        String email = texto(request.getUsuarioEmail());
        if (email != null) {
            return usuarioRepository.findByEmailIgnoreCase(email)
                    .orElseGet(() -> criarUsuario(request));
        }

        return criarUsuario(request);
    }

    private Usuario criarUsuario(PedidoRequest request) {
        Usuario usuario = new Usuario();
        usuario.setId(request.getUsuarioId());
        usuario.setNome(texto(request.getUsuarioNome()) == null ? "Cliente" : texto(request.getUsuarioNome()));
        usuario.setEmail(texto(request.getUsuarioEmail()));
        usuario.setSenha("");
        usuario.setPerfil("USER");
        usuario.setDataCadastro(LocalDateTime.now());
        return usuarioRepository.save(usuario);
    }

    private String montarEnderecoEntrega(PedidoRequest request, Usuario usuario) {
        String endereco = texto(request.getEnderecoEntrega());
        if (endereco != null) {
            return endereco;
        }
        return usuario.getEndereco();
    }

    private String texto(String valor) {
        if (valor == null || valor.isBlank()) {
            return null;
        }
        return valor.trim();
    }
}
