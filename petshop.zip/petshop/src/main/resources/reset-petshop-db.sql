DROP DATABASE IF EXISTS petshop_db;
CREATE DATABASE petshop_db;
USE petshop_db;

CREATE TABLE usuarios (
  id INT(11) NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255),
  email VARCHAR(255),
  senha VARCHAR(255),
  perfil VARCHAR(20),
  endereco VARCHAR(255),
  bairro VARCHAR(100),
  complemento VARCHAR(100),
  cep VARCHAR(20),
  cidade VARCHAR(100),
  estado VARCHAR(50),
  foto LONGTEXT,
  data_cadastro DATETIME,
  PRIMARY KEY (id)
);

CREATE TABLE categoria (
  id_categoria INT(11) NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100),
  descricao TEXT,
  ativo TINYINT(1),
  PRIMARY KEY (id_categoria)
);

CREATE TABLE produto (
  id_produto INT(11) NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255),
  descricao TEXT,
  preco DECIMAL(10,2),
  preco_desconto DECIMAL(10,2),
  imagem LONGTEXT,
  sku VARCHAR(50),
  qtd_estoque INT(11),
  ativo TINYINT(1),
  id_categoria INT(11),
  data_criacao DATETIME,
  PRIMARY KEY (id_produto),
  CONSTRAINT fk_produto_categoria
    FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria)
);

CREATE TABLE pedidos (
  id_pedido INT(11) NOT NULL AUTO_INCREMENT,
  id_usuario_fk INT(11) NOT NULL,
  data_pedido DATETIME,
  status VARCHAR(50),
  valor_total DECIMAL(10,2),
  endereco_entrega VARCHAR(255),
  PRIMARY KEY (id_pedido),
  CONSTRAINT fk_pedidos_usuarios
    FOREIGN KEY (id_usuario_fk) REFERENCES usuarios(id)
);

CREATE TABLE itens_pedido (
  id_item_pedido INT(11) NOT NULL AUTO_INCREMENT,
  id_pedido_fk INT(11) NOT NULL,
  id_produto_fk INT(11) NOT NULL,
  nome_produto VARCHAR(255),
  quantidade INT(11),
  preco_unitario DECIMAL(10,2),
  PRIMARY KEY (id_item_pedido),
  CONSTRAINT fk_itens_pedido_pedidos
    FOREIGN KEY (id_pedido_fk) REFERENCES pedidos(id_pedido),
  CONSTRAINT fk_itens_pedido_produto
    FOREIGN KEY (id_produto_fk) REFERENCES produto(id_produto)
);

INSERT INTO categoria (id_categoria, nome, descricao, ativo) VALUES
  (1, 'Cachorros', 'Produtos para cachorros', 1),
  (2, 'Gatos', 'Produtos para gatos', 1),
  (3, 'Passaros', 'Produtos para passaros', 1),
  (4, 'Coelhos', 'Produtos para coelhos', 1);
