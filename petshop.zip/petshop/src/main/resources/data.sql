USE petshop_db;

INSERT INTO categoria (id_categoria, nome, descricao, ativo) VALUES
  (1, 'Cachorros', 'Produtos para cachorros', 1),
  (2, 'Gatos', 'Produtos para gatos', 1),
  (3, 'Passaros', 'Produtos para passaros', 1),
  (4, 'Coelhos', 'Produtos para coelhos', 1)
ON DUPLICATE KEY UPDATE
  nome = VALUES(nome),
  descricao = VALUES(descricao),
  ativo = VALUES(ativo);
