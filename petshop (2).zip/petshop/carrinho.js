if (exigirLogin()) {
  renderizarCarrinho();
}

function renderizarCarrinho() {
  const lista = document.getElementById("listaCarrinho");
  const carrinho = obterCarrinho();

  if (carrinho.length === 0) {
    lista.innerHTML = `<div class="bg-white rounded-xl shadow p-6 text-gray-500">Seu carrinho esta vazio.</div>`;
  } else {
    lista.innerHTML = carrinho.map(item => `
      <div class="bg-white rounded-xl shadow p-4 flex items-center justify-between gap-4">
        <div>
          <h2 class="font-bold">${item.nome}</h2>
          <p class="text-sm text-gray-500">Quantidade: ${item.quantidade}</p>
        </div>
        <div class="text-right">
          <p class="font-bold">R$ ${(item.preco * item.quantidade).toFixed(2)}</p>
          <button onclick="removerDoCarrinho(${item.id})" class="text-red-500 text-sm font-semibold">Remover</button>
        </div>
      </div>
    `).join("");
  }

  const total = carrinho.reduce((soma, item) => soma + item.preco * item.quantidade, 0);
  document.getElementById("totalCarrinho").textContent = `Total: R$ ${total.toFixed(2)}`;
}

function removerDoCarrinho(id) {
  salvarCarrinho(obterCarrinho().filter(item => Number(item.id) !== Number(id)));
  renderizarCarrinho();
}

function confirmarCompra() {
  const pedido = finalizarCompra();

  if (!pedido) {
    alert("Adicione produtos ao carrinho antes de finalizar.");
    return;
  }

  alert("Compra finalizada com sucesso!");
  window.location.href = "pedidos.html";
}
