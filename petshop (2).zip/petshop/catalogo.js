const API = "http://localhost:8080";
const IMAGEM_PADRAO = "https://placehold.co/400x300";
const params = new URLSearchParams(window.location.search);
const categoriaId = params.get("categoria");
const busca = (params.get("busca") || "").trim().toLowerCase();

function montarUrlImagem(imagem) {
  if (!imagem || imagem === "null" || imagem === "undefined") {
    return IMAGEM_PADRAO;
  }

  const caminho = String(imagem).trim().replace(/^["']|["']$/g, "");

  if (
    caminho.startsWith("http://") ||
    caminho.startsWith("https://") ||
    caminho.startsWith("data:") ||
    caminho.startsWith("blob:")
  ) {
    return caminho;
  }

  if (caminho.startsWith("/uploads/")) {
    return `${API}${caminho}`;
  }

  if (caminho.startsWith("uploads/")) {
    return `${API}/${caminho}`;
  }

  const nomeArquivo = caminho.split("\\").pop().split("/").pop();
  return `${API}/uploads/${nomeArquivo}`;
}

function escaparHtml(texto) {
  return String(texto ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function resumirDescricao(descricao, limite = 70) {
  const texto = String(descricao || "").trim();

  if (texto.length <= limite) {
    return texto;
  }

  return `${texto.slice(0, limite).trim()}... mais`;
}

function produtoCorrespondeBusca(produto) {
  if (!busca) {
    return true;
  }

  return [
    produto.nome,
    produto.descricao,
    produto.categoria?.nome
  ].some(campo => String(campo || "").toLowerCase().includes(busca));
}

function obterCategoriaIdProduto(produto) {
  return String(
    produto.categoria?.idCategoria ??
    produto.categoria?.id ??
    produto.idCategoria ??
    produto.categoriaId ??
    ""
  );
}

function atualizarTitulo(produtos) {
  const titulo = document.getElementById("tituloCatalogo");
  const subtitulo = document.getElementById("subtituloCatalogo");

  if (busca) {
    titulo.textContent = `Resultado para "${busca}"`;
    subtitulo.textContent = `${produtos.length} ${produtos.length === 1 ? "produto encontrado" : "produtos encontrados"}`;
    return;
  }

  if (categoriaId && produtos[0]?.categoria?.nome) {
    titulo.textContent = produtos[0].categoria.nome;
    subtitulo.textContent = "Produtos disponíveis nesta categoria";
  }
}

function montarCardProduto(produto) {
  const produtoId = produto.idProduto ?? produto.id;
  const imagem = montarUrlImagem(produto.imagem);
  const descricao = escaparHtml(resumirDescricao(produto.descricao));

  return `
    <a href="descricao.html?id=${produtoId}" class="h-full">
      <div class="bg-white rounded-2xl shadow-md overflow-hidden h-full min-h-[520px] flex flex-col hover:shadow-lg transition">
        <div class="h-56 bg-gray-100 flex items-center justify-center">
          <img
            src="${imagem}"
            class="w-full h-full object-contain p-3"
            onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'"
          >
        </div>

        <div class="p-5 flex flex-col flex-1">
          <h2 class="font-bold text-lg text-gray-800 mb-1 h-14 overflow-hidden">
            ${escaparHtml(produto.nome)}
          </h2>

          <p class="font-normal text-gray-600 h-20 overflow-hidden">
            ${descricao}
          </p>

          <div class="mt-auto">
            <p class="text-2xl font-extrabold text-gray-700 mb-2">
              R$ ${Number(produto.preco || 0).toFixed(2)}
            </p>

            <p class="text-sm text-gray-400 mb-4">
              Estoque: ${produto.qtdEstoque ?? 0}
            </p>

            <button class="w-full bg-yellow-300 hover:bg-yellow-500 text-white font-semibold py-2 rounded-lg">
              Ver produto
            </button>
          </div>
        </div>
      </div>
    </a>
  `;
}

function renderizarProdutos(produtos) {
  const container = document.getElementById("listaCatalogo");
  container.innerHTML = "";

  produtos = produtos.filter(produtoCorrespondeBusca);
  atualizarTitulo(produtos);

  if (produtos.length === 0) {
    container.innerHTML = `
      <p class="col-span-full text-center text-gray-500 text-lg">
        Nenhum produto encontrado.
      </p>
    `;
    return;
  }

  container.innerHTML = produtos.map(montarCardProduto).join("");
}

function normalizarListaProdutos(dados) {
  if (Array.isArray(dados)) {
    return dados;
  }

  if (Array.isArray(dados?.content)) {
    return dados.content;
  }

  if (Array.isArray(dados?.produtos)) {
    return dados.produtos;
  }

  return [];
}

function buscarJson(url) {
  return fetch(url).then(res => {
    if (!res.ok) {
      throw new Error(`Erro ${res.status}`);
    }

    return res.json();
  });
}

function buscarProdutosPorCategoriaComFallback() {
  return buscarJson(`${API}/api/produtos/categoria/${categoriaId}`)
    .then(dados => {
      const produtos = normalizarListaProdutos(dados);

      if (produtos.length > 0) {
        return produtos;
      }

      return buscarProdutosFiltradosNoFront();
    })
    .catch(buscarProdutosFiltradosNoFront);
}

function buscarProdutosFiltradosNoFront() {
  return buscarJson(`${API}/produto`)
    .then(dados => normalizarListaProdutos(dados))
    .then(produtos => produtos.filter(produto =>
      obterCategoriaIdProduto(produto) === String(categoriaId)
    ));
}

function carregarProdutos() {
  const requisicao = categoriaId
    ? buscarProdutosPorCategoriaComFallback()
    : buscarJson(`${API}/produto`).then(normalizarListaProdutos);

  requisicao
    .then(renderizarProdutos)
    .catch(err => console.error("Erro produtos:", err));
}

carregarProdutos();
