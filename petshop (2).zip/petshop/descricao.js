const API = "http://localhost:8080";
const IMAGEM_PADRAO = "https://placehold.co/500x500";

function montarUrlImagem(imagem) {
  if (!imagem || imagem === "null" || imagem === "undefined") {
    return IMAGEM_PADRAO;
  }

  const caminho = String(imagem).trim().replace(/^["']|["']$/g, "");

  if (
    caminho.startsWith("http://") ||
    caminho.startsWith("https://") ||
    caminho.startsWith("data:") ||
    caminho.startsWith("blob:")
  ) {
    return caminho;
  }

  if (caminho.startsWith("/uploads/")) {
    return `${API}${caminho}`;
  }

  if (caminho.startsWith("uploads/")) {
    return `${API}/${caminho}`;
  }

  const nomeArquivo = caminho.split("\\").pop().split("/").pop();
  return `${API}/uploads/${nomeArquivo}`;
}

function obterImagensProduto(produto) {
  const imagens = [
    produto.imagem,
    produto.imagem2,
    produto.imagem3,
    produto.foto,
    produto.foto2,
    produto.foto3,
    ...(Array.isArray(produto.imagens) ? produto.imagens : []),
    ...(Array.isArray(produto.fotos) ? produto.fotos : [])
  ];

  const urls = imagens
    .filter(imagem => imagem && imagem !== "null" && imagem !== "undefined")
    .map(montarUrlImagem);

  return [...new Set(urls)].slice(0, 3);
}

function trocarImagemPrincipal(src, botao) {
  const imagemPrincipal = document.getElementById("imagemPrincipalProduto");

  if (!imagemPrincipal) {
    return;
  }

  imagemPrincipal.src = src;

  document.querySelectorAll("[data-miniatura-produto]").forEach(miniatura => {
    miniatura.classList.remove("border-pink-400", "ring-2", "ring-pink-200");
    miniatura.classList.add("border-transparent");
  });

  botao.classList.remove("border-transparent");
  botao.classList.add("border-pink-400", "ring-2", "ring-pink-200");
}

const params = new URLSearchParams(window.location.search);
const id = params.get("id");

fetch(`${API}/produto/${id}`)
  .then(res => res.json())
  .then(p => {

    const imagens = obterImagensProduto(p);
    const imagem = imagens[0] || IMAGEM_PADRAO;
    const miniaturas = imagens.length > 0 ? imagens : [IMAGEM_PADRAO];

    document.getElementById("produto").innerHTML = `
      <!-- IMAGEM -->
      <div class="flex gap-4">
        <div class="flex flex-col gap-3 w-20 flex-shrink-0">
          ${miniaturas.map((miniatura, index) => `
            <button
              type="button"
              data-miniatura-produto
              onclick="trocarImagemPrincipal('${miniatura}', this)"
              class="w-20 h-20 rounded-xl bg-gray-100 border-2 ${index === 0 ? "border-pink-400 ring-2 ring-pink-200" : "border-transparent"} overflow-hidden transition"
            >
              <img
                src="${miniatura}"
                class="w-full h-full object-contain p-1"
                onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'"
              >
            </button>
          `).join("")}
        </div>

        <div class="flex-1 min-w-0">
          <img
            id="imagemPrincipalProduto"
            src="${imagem}"
            class="w-full h-[500px] object-contain bg-gray-100 p-4 rounded-2xl"
            onerror="this.onerror=null; this.src='${IMAGEM_PADRAO}'"
          >
        </div>
      </div>

      <!-- INFO -->
      <div class="flex flex-col justify-center">

        <span class="text-sm text-pink-500 font-bold uppercase">
          ${p.categoria?.nome || ""}
        </span>

        <h1 class="text-4xl font-bold mt-2">
          ${p.nome}
        </h1>

        <p class="text-gray-600 mt-4 text-lg">
          ${p.descricao || ""}
        </p>

        <p class="text-3xl font-bold text-pink-600 mt-6">
          R$ ${Number(p.preco).toFixed(2)}
        </p>

        <p class="text-gray-500 mt-3">
          Estoque: ${p.qtdEstoque ?? 0}
        </p>

        <button class="mt-8 bg-pink-400 hover:bg-pink-500 text-white py-3 rounded-xl text-lg font-bold transition">
          Comprar
        </button>

      </div>
    `;
  })
  .catch(err => console.error("Erro produto:", err));
