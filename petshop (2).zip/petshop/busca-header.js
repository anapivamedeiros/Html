function iniciarBuscaHeader() {
  const header = document.querySelector("header");

  if (!header || document.getElementById("buscaHeaderForm")) {
    return;
  }

  const paginaAtual = window.location.pathname.split("/").pop() || "index.html";

  if (paginaAtual !== "index.html" && !document.getElementById("botaoVoltarHeader")) {
    const botaoVoltar = document.createElement("button");
    botaoVoltar.id = "botaoVoltarHeader";
    botaoVoltar.type = "button";
    botaoVoltar.textContent = "←";
    botaoVoltar.title = "Voltar";
    botaoVoltar.className = "mr-4 w-10 h-10 rounded-full bg-pink-50 text-pink-600 text-2xl font-bold hover:bg-pink-100 transition flex items-center justify-center";
    botaoVoltar.addEventListener("click", () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "index.html";
      }
    });

    header.insertBefore(botaoVoltar, header.firstElementChild);
  }

  const form = document.createElement("form");
  form.id = "buscaHeaderForm";
  form.className = "hidden lg:flex items-center w-64";
  form.innerHTML = `
    <input
      id="buscaHeaderInput"
      type="search"
      placeholder="Buscar produto..."
      class="w-full border border-pink-100 bg-white rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-pink-200"
    >
  `;

  form.addEventListener("submit", event => {
    event.preventDefault();

    const termo = form.querySelector("input").value.trim();

    if (termo) {
      window.location.href = `catalogo.html?busca=${encodeURIComponent(termo)}`;
    }
  });

  const configuracao = header.querySelector('a[href="configuracao.html"]');
  header.insertBefore(form, configuracao || null);
}

document.addEventListener("DOMContentLoaded", iniciarBuscaHeader);
