if (exigirLogin()) {
  renderizarPedidos();
}

function renderizarPedidos() {
  const usuario = obterUsuarioLogado();
  const pedidos = obterPedidos().filter(pedido =>
    usuario.role === "ADMIN" || pedido.usuarioId === usuario.id
  );
  const lista = document.getElementById("listaPedidos");

  if (pedidos.length === 0) {
    lista.innerHTML = `<div class="bg-white rounded-xl shadow p-6 text-gray-500">Nenhum pedido encontrado.</div>`;
    return;
  }

  lista.innerHTML = pedidos.map(pedido => `
    <article class="bg-white rounded-xl shadow p-5 border border-pink-100">
      <div class="flex justify-between gap-4 flex-wrap">
        <div>
          <h2 class="font-bold text-lg">Pedido #${pedido.id}</h2>
          <p class="text-sm text-gray-500">${pedido.data} - ${pedido.status}</p>
          <p class="text-sm text-gray-500">${pedido.usuarioNome}</p>
        </div>
        <strong>R$ ${pedido.total.toFixed(2)}</strong>
      </div>
      <ul class="mt-4 text-sm text-gray-600 space-y-1">
        ${pedido.itens.map(item => `<li>${item.quantidade}x ${item.nome} - R$ ${(item.preco * item.quantidade).toFixed(2)}</li>`).join("")}
      </ul>
    </article>
  `).join("");
}
