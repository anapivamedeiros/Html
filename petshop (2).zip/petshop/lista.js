const API = "http://localhost:8080/categoria";

function listarCategorias() {

  fetch(API)
    .then(res => res.json())
    .then(categorias => {

      const div = document.getElementById("categorias");

      div.innerHTML = "";

      categorias.forEach(c => {
        const categoriaId = c.idCategoria ?? c.id;

        div.innerHTML += `

          <a href="catalogo.html?categoria=${categoriaId}">

            <div class="bg-white px-8 py-4 rounded-xl shadow-md text-xl font-bold hover:scale-105 transition cursor-pointer">

              ${c.nome}

            </div>

          </a>

        `;
      });

    })
    .catch(err => console.error(err));
}

window.onload = listarCategorias;
